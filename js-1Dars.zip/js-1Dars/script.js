var name1 = prompt("Ismingizni Kiriting")
console.log("Sizning Ismingiz "+name1);
var age = prompt("Yoshingizni Kiriting")
console.log("Sizning Yoshingiz "+age);
var mashq1 = prompt("29+4=?")
console.log("29+4=? "+mashq1);
var mashq2 = prompt("25-17=?")
console.log("25-17=? "+mashq2);
var mashq3 = prompt("8*6")
console.log("8*6= "+mashq3);
var mashq4 = prompt("34/3=?")
console.log("34/3= "+mashq4);
var mashq5 = prompt("16%3=?")
console.log("16%3=? "+mashq5);
var alert1 = alert("Tabriklayman "+name1+" Testdan Muvafaqiyatli o'tdingiz")
console.log(alert1);
console.log("Tabriklayman "+name1+" Testdan Muvafaqiyatli o'tdingiz");